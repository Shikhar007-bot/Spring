package com.excelr.autowiring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Driver {

	public static void main(String[] args) {
	
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(config.class);
		
		Person person = context.getBean(Person.class);
		Vechicle vechile = context.getBean(Vechicle.class);
		
		System.out.println(person.getName());
		System.out.println(person.getVechicle());
		System.out.println(vechile.getName());
		
		
		
		

	}

}
