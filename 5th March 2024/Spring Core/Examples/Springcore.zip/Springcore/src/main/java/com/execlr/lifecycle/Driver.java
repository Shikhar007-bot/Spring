package com.execlr.lifecycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Driver {

	public static void main(String[] args) {
		
		AbstractApplicationContext ctx= new ClassPathXmlApplicationContext("beanlifecycle.xml");
		
		Country c1= (Country) ctx.getBean("country");
		
		System.out.println("Country Name :" + c1.getCountryName());
		
		ctx.registerShutdownHook();
		

	}

}
