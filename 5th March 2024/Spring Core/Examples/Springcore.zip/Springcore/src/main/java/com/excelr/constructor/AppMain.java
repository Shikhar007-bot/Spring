package com.excelr.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain {

	public static void main(String[] args) {
		ApplicationContext ctx= new ClassPathXmlApplicationContext("bean.xml");
	
		Emp emp = (Emp) ctx.getBean("obj2");
		emp.display();

	}

}
