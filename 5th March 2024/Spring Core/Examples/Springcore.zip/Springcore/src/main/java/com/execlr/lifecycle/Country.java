package com.execlr.lifecycle;

public class Country {
	
	String countryName;

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	public void init() {
		System.out.println("init block");
	}
	
	public void destroy() {
		System.out.println("destroy block");
	}
	

}
