package com.excelr.autowiring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Person {
	
	private String name="Vijay";
	
	private Vechicle vechicle;
	
	@Autowired
	public Person(Vechicle vechicle){
		System.out.println("person bean created by spring");
		this.vechicle=vechicle;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Vechicle getVechicle() {
		return vechicle;
	}

	public void setVechicle(Vechicle vechicle) {
		this.vechicle = vechicle;
	}

	

}
