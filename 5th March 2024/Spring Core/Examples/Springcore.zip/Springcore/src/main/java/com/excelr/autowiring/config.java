package com.excelr.autowiring;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.excelr.autowiring")
public class config {
	
	
}
