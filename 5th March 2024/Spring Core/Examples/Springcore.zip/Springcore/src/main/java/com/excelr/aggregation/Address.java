package com.excelr.aggregation;

public class Address {
	
	String city,state, country; //dependency

	public Address(String city, String state, String country) {
		super();
		this.city = city;
		this.state = state;
		this.country = country;
	}

}
