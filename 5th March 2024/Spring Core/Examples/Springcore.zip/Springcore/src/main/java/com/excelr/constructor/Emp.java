package com.excelr.constructor;

public class Emp {

	private int id;// dependency
	private String name;// dependency
	private PAddress address;// Address dependency

	public Emp(int id, String name, PAddress address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}

	public void display() {
		System.out.println(id + " " + name);
		System.out.println(address);
	}

}
