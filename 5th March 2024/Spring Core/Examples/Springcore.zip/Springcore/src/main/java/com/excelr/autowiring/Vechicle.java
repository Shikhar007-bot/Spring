package com.excelr.autowiring;

import org.springframework.stereotype.Component;

@Component
public class Vechicle {
	
	private String name="Tyota";
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void Hello() {
		System.out.println("hello");
	}
	
	@Override
	public String toString() {
		return "Vechicle  name is " + name;
	}

	public Vechicle() {
		System.out.println("Vechicle bean created by Spring");
	}

}
