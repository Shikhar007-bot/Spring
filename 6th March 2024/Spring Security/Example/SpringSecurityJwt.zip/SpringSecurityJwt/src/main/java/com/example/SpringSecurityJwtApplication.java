package com.example;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.filter.JwtRequestFilter;
import com.example.model.MyGrantedAuthority;
import com.example.model.User;
import com.example.repository.AuthorityRepo;
import com.example.repository.UserRepo;

@SpringBootApplication
public class SpringSecurityJwtApplication implements CommandLineRunner{
	
	@Autowired
	JwtRequestFilter jwtFilter;
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	AuthorityRepo authRepo;

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityJwtApplication.class, args);
	}
	
	
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		
		http.csrf().disable()
		.authorizeRequests()
		.antMatchers("/home")
		.hasRole("ADMIN")
		.antMatchers("/authenticate")
		.permitAll()
		.and()
		.sessionManagement()
		.sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		
		 http.addFilterBefore(jwtFilter,UsernamePasswordAuthenticationFilter.class);
		
		
		return http.build();
		
		
	}
	
	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
		
		return config.getAuthenticationManager();
	}
	
	
	@Bean
	public PasswordEncoder getEncoder() {
		
		return new BCryptPasswordEncoder();
		
	}


	@Override
	public void run(String... args) throws Exception {
		
		User user=new User();
		
		user.setUsername("mno");
		user.setPassword(getEncoder().encode("2222"));
		user.setAccountNonExpired(true);
		user.setAccountNonLocked(true);
		user.setEnabled(true);
		user.setCredentialsNonExpired(true);
		
		MyGrantedAuthority auth=new MyGrantedAuthority();
		
		auth.setAuthority("ROLE_ADMIN");
		
		user.setAuthorities(Arrays.asList(auth));
		
		authRepo.save(auth);
		
		userRepo.save(user);
		
		
		
	}
	
	
	
	

}
