package com.example.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {

	@Autowired
	UserDetailsService userDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		if (request.getServletPath().equals("/authenticate")) {

			filterChain.doFilter(request, response);

		} else {

			String authorizeHeader = request.getHeader("Authorization");

			if (authorizeHeader != null && authorizeHeader.startsWith("Bearer ")) {

				String token = authorizeHeader.substring("Bearer ".length());

				try {
					Algorithm a = Algorithm.HMAC256("helloworld");

					JWTVerifier v = JWT.require(a).build();

					DecodedJWT decodeJwt = v.verify(token);

					String name = decodeJwt.getSubject();

					System.out.println(name);

					UserDetails userDetails = userDetailsService.loadUserByUsername(name);

					UsernamePasswordAuthenticationToken upa = new UsernamePasswordAuthenticationToken(
							userDetails.getUsername(), userDetails.getPassword(), userDetails.getAuthorities());

					System.out.println(userDetails.getPassword());
					SecurityContextHolder.getContext().setAuthentication(upa);

					filterChain.doFilter(request, response);

				} catch (Exception e) {
					e.printStackTrace();
					filterChain.doFilter(request, response);
				}

			}

		}

	}

}
