package com.example.service;
import org.springframework.stereotype.Service;

@Service
public class NameService {

    public String getGreeting() {
        
        return "Good Afternoon";
        		
    }
}
