package com.example.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.NameService;

@RestController
public class AppController {

	@Autowired
    private  NameService nameService;

    @GetMapping("/hello")
    public String hello() {
    	return "Welcome to Spring Boot";
    }

    @GetMapping("/greet")
    public String greetPerson() {
        return nameService.getGreeting();
    }
}
