package com.example.stream;
import java.util.ArrayList;
import java.util.List;

public class CollectionMod {
    public static void main(String[] args) {
        // Creating an ArrayList of String using List interface
        List<String> fruits = new ArrayList<>();
        
        // Adding new elements to the ArrayList
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("Mango");
        fruits.add("Orange");
        fruits.add("Pineapple");
        fruits.add("Grapes");
        
        // Print the ArrayList
        System.out.println(fruits);

        // Remove the element at index `5`
        fruits.remove(5);
        
        // Print the ArrayList after removal
        System.out.println("After remove(5): " + fruits);
    }
}
