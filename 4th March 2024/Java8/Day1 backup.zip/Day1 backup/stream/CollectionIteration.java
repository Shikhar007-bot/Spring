package com.example.stream;
import java.util.ArrayList;
import java.util.List;

public class CollectionIteration {
    public static void main(String[] args) {
        // Creating an ArrayList of String using List interface
        List<String> fruits = new ArrayList<>();

        // Adding new elements to the ArrayList
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("Mango");
        fruits.add("Orange");
        fruits.add("Watermelon");
        fruits.add("Strawberry");

        System.out.println("\n=== Iterate using for loop with index ===");
        // Iterate using a for loop with index
        for (int i = 0; i < fruits.size(); i++) {
            System.out.println(fruits.get(i));
        }

        System.out.println("=== Iterate using Java 8 forEach and lambda ===");
        // Iterate using Java 8 forEach and lambda
        fruits.forEach(fruit -> {
            System.out.println(fruit);
        });
    }
}
