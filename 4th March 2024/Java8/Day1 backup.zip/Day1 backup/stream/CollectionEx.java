package com.example.stream;
import java.util.ArrayList;
import java.util.List;

public class CollectionEx {
    public static void main(String[] args) {
        // Creating an ArrayList of String using List interface
        List<String> fruits = new ArrayList<>();
        
        // Adding new elements to the ArrayList
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("Mango");
        fruits.add("Orange");
        
        // Using a for-each loop to iterate over the elements of the ArrayList
        System.out.println("Fruits:");
        for (String fruit : fruits) {
            System.out.println(fruit);
        }
    }
}
