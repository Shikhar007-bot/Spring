package com.example.stream;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamTraverse2 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(4, 2, 8, 9, 5, 6, 7);
        
        // Create a stream of integers greater than 5
        Stream<Integer> numbersGreaterThan5 = numbers.stream().filter(i -> i > 5);
        
        // Traversing numbersGreaterThan5 stream first time
        numbersGreaterThan5.forEach(System.out::println);
        
        // Recreate the stream for the second traversal
        numbersGreaterThan5 = numbers.stream().filter(i -> i > 5);
        
        // Second time traversal
        numbersGreaterThan5.forEach(System.out::println); // This will not throw an error
    }
}
