package com.example.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamIteration {
	public static void main(String[] args) {
		List<String> lines = Arrays.asList("java", "c", "python");

		List<String> result = lines.stream() // convert list to stream
				.collect(Collectors.toList()); // collect the output and convert streams to a List

		result.forEach(System.out::println); // print each element of the resulting list
	}
}
