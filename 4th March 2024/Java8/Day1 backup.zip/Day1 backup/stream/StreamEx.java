package com.example.stream;

//a simple program to demonstrate the use of stream in java
import java.util.*;
import java.util.stream.*;

class StreamEx {
	public static void main(String args[]) {

		// create a list of integers
		List<Integer> number = Arrays.asList(2, 3, 4, 5);

		// demonstration of map method
		List<Integer> square = number.stream().map(x -> x * x).collect(Collectors.toList());
		//System.out.println(square);
		square.forEach(System.out::println);
		// create a list of String
		List<String> names = Arrays.asList("Reflection", "Collection", "Stream");

		// demonstration of filter method
		List<String> result = names.stream().filter(s -> s.startsWith("S")).collect(Collectors.toList());
		System.out.println(result);

		// demonstration of sorted method
		List<String> show = names.stream().sorted().collect(Collectors.toList());
		System.out.println(show);

		// create a list of integers
		List<Integer> numbers = Arrays.asList(2, 3, 4, 5, 2);

		// collect method returns a set
		Set<Integer> squareSet = numbers.stream().map(x -> x * x).collect(Collectors.toSet());
		System.out.println(squareSet);


		// demonstration of forEach method
		/**
		 * x represents each element in the stream before being squared 
		 * (in this case, each "number" in the collection represented by 
		 * the variable number).
		 *y represents each element in the stream after being squared.
		 */
		number.stream().map(x -> x * x).forEach(y -> System.out.println(y));

		List<String> names2 = Arrays.asList("Vijay", "Lakshmi", "Venkat", "Sai");

		// Filter names starting with 'A' and print them
		names2.stream()
		     .filter(name -> name.startsWith("V"))
		     .forEach(System.out::println);

	}
}
