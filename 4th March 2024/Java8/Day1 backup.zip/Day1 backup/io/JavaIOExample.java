package com.example.io;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class JavaIOExample {
    public static void main(String[] args) {
        // Example 1: Reading all lines from a file into a List<String>
        try {
            Path filePath = Paths.get("e://example.txt");
            List<String> lines = Files.readAllLines(filePath);
            System.out.println("Lines read from file:");
            for (String line : lines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        // Example 2: Writing lines to a file
        try {
            Path outputPath = Paths.get("e://output.txt");
            List<String> data = List.of("Line 1", "Line 2", "Line 3");
            Files.write(outputPath, data);
            System.out.println("Data written to output.txt");
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }

        // Example 3: Getting file attributes
        try {
            Path filePath = Paths.get("e://example.txt");
            long size = Files.size(filePath);
            boolean isDirectory = Files.isDirectory(filePath);
            System.out.println("File size: " + size + " bytes");
            System.out.println("Is directory: " + isDirectory);
        } catch (IOException e) {
            System.err.println("Error getting file attributes: " + e.getMessage());
        }
    }
}
