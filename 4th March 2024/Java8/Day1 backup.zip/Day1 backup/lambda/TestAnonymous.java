package com.ust.lambda;

public class TestAnonymous {

	public static void main(String[] args) {

		Animal a1 = new Animal() {
			public void makeSound() {
				System.out.println("Woof-Woof");
			}
		};
		a1.makeSound();

	}

}
