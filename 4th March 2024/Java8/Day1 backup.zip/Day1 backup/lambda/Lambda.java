package com.ust.lambda;

public class Lambda {

	public static void main(String[] args) {
		
		Animal a1= ()->System.out.println("Woof-Woof");
		a1.makeSound();

	}

}
