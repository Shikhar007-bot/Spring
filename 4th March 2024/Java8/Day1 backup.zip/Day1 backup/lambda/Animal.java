package com.ust.lambda;

public interface Animal {
	
	abstract void makeSound();

}
