package com.ust.lambda;

public class AnimapImpl implements Animal {

	@Override
	public void makeSound() {
		System.out.println("Woof-Woof");

	}

	public static void main(String[] args) {
		
		Animal a1= new AnimapImpl();
		a1.makeSound();

	}

}
