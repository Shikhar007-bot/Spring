package com.example.concurrent;
//Atomic Updates
import java.util.concurrent.atomic.AtomicInteger;

public class AtomicUpdatesExample {
    public static void main(String[] args) {
        AtomicInteger atomicInt = new AtomicInteger(0);
        int updatedValue = atomicInt.updateAndGet(n -> n + 2);
        System.out.println(updatedValue); // Output: 2
    }
}
