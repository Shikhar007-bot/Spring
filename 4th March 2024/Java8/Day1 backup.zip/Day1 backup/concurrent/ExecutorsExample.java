package com.example.concurrent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ExecutorsExample {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newWorkStealingPool();

        executor.submit(() -> System.out.println("Task executed by work-stealing pool"));

        executor.shutdown();
        
        try {
            // Wait for all tasks to finish or for a timeout
            executor.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // Handle interruption
            e.printStackTrace();
        }
    }
}
