package com.example.concurrent;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class CompletableFutureExample {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return "Hello, ";
		});

		CompletableFuture<String> completedFuture = future.thenApply(result -> result + "world");

		String result = completedFuture.get();
		System.out.println(result); // Output: Hello, world
	}
}
