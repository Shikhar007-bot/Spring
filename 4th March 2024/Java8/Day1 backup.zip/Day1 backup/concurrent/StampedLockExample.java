package com.example.concurrent;
import java.util.concurrent.locks.StampedLock;
/**
 * This example demonstrates the usage of StampedLock to manage
 * concurrent access to mutable variables x and y.
 *  
 * The move() method acquires a write lock to update the variables,
 * ensuring exclusive access during modification. 
 * 
 * The distanceFromOrigin() method calculates the distance 
 * from the origin using optimistic locking. 
 * 
 * It first tries to obtain an optimistic read lock 
 * and then checks if the lock is still valid. If not, 
 * it acquires a read lock to ensure consistent access to x and y.
 *  
 * Finally, it calculates the distance and returns the result. 
 * The main() method provides a simple test case for the move() 
 * and distanceFromOrigin() methods.
 * 
 *
 */
public class StampedLockExample {
    private double x, y;
    private final StampedLock lock = new StampedLock();

    void move(double deltaX, double deltaY) {
        long stamp = lock.writeLock();
        try {
            x += deltaX;
            y += deltaY;
        } finally {
            lock.unlockWrite(stamp);
        }
    }

    double distanceFromOrigin() {
        long stamp = lock.tryOptimisticRead();
        double currentX = x;
        double currentY = y;
        if (!lock.validate(stamp)) {
            stamp = lock.readLock();
            try {
                currentX = x;
                currentY = y;
            } finally {
                lock.unlockRead(stamp);
            }
        }
        return Math.sqrt(currentX * currentX + currentY * currentY);
    }

    public static void main(String[] args) {
        StampedLockExample example = new StampedLockExample();
        example.move(3.0, 4.0);
        System.out.println("Distance from origin: " + example.distanceFromOrigin());
    }
}

