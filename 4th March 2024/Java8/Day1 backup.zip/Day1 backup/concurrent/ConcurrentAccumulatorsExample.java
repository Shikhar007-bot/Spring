package com.example.concurrent;
import java.util.concurrent.atomic.LongAccumulator;
//Concurrent Accumulators
public class ConcurrentAccumulatorsExample {
    public static void main(String[] args) {
        LongAccumulator accumulator = new LongAccumulator((x, y) -> x + y, 0);
        accumulator.accumulate(5);
        accumulator.accumulate(10);
        long result = accumulator.get();
        System.out.println(result); // Output: 15
    }
}
