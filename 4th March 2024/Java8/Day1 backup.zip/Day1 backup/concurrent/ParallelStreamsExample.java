package com.example.concurrent;
import java.util.Arrays;

public class ParallelStreamsExample {
    public static void main(String[] args) {
        Arrays.asList(1, 2, 3, 4, 5)
                .parallelStream()
                .map(i -> i * 2)
                .forEach(System.out::println);
    }
}
