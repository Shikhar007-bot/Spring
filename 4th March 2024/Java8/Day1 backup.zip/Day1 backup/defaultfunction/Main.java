package com.ust.defaultfunction;
interface Vehicle {
    void start();
    
    default void honk() {
        System.out.println("Honking horn");
    }
}

class Car implements Vehicle {
    public void start() {
        System.out.println("Starting car");
    }
}

public class Main {
    public static void main(String[] args) {
        Car car = new Car();
        car.start();
        car.honk(); // Default method from interface
    }
}
